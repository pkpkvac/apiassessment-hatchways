0/ Install the dependencies [please let me know if there is an issue after this step]

	npm install

------------------

1/ Start the server

	npm start

------------------

2/ Make request to the API

In the browser, here are some example request(s) you can make to the API endpoint:

	http://localhost:8080/api/ping
	http://localhost:8080/api/posts/history
	http://localhost:8080/api/posts/history/likes
	http://localhost:8080/api/posts/history/likes/asc
	http://localhost:8080/api/posts/history/likes/desc

------------------

3/ Run the test suite

	npm test


